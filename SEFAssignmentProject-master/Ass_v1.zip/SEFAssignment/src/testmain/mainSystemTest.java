package testmain;

import userInterface.SystemMenu;

public class mainSystemTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//test userInterface
		SystemMenu ui = new SystemMenu();
		//ui.mainMenu();
		//ui.loginMenu();
		ui.memberMenu();
		
	}

	public static boolean validateCredentials(String loginInfo) {
		// TODO Auto-generated method stub
		return true;
	}

}
