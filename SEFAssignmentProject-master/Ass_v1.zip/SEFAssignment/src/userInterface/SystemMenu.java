package userInterface;

import java.util.Scanner;

import testmain.mainSystemTest;

public class SystemMenu {
	/* Author: Raphael Wong
	 * Description: To show various menu for the supermarket system
	 */
	
	Scanner scanner = new Scanner(System.in);
	
	public int mainMenu() {
		//main menu of system, give choice of main functions to user
		//returns int value , 1 for shopping, 2 for login
		int choice = 0;
		
		System.out.println("----------\tHome Supermarket - Main Menu\t----------");
		
		while (choice == 0)
		{
			System.out.println("\nPlease select the following options by entering the number listed:");
			System.out.println("1. Shop for Items\n2. Login\n");
			System.out.printf(":");
			choice = scanner.nextInt();
			
			//validate Input
			if (choice == 1 || choice == 2)
			{
				break;
			}
			
			System.out.println("\nInvalid Input!\n");
			choice = 0;
		}
		
		System.out.println();
		return choice;
	}
	
	public String loginMenu() {
		//login menu for member and employee
		String loginInfo = "";
		boolean valid = false;
		
		System.out.println("---\tLogin Menu\t---");
		
		while (valid == false) {
			
			System.out.printf("\nUser ID: ");
			loginInfo = scanner.next();
			
			//cancel login
			if(loginInfo.equals("cancel"))
			{
				System.out.println("\nLogin cancelled. Returning to main menu");
				break;
			}
			
			System.out.printf("Password: ");
			loginInfo += "$" + scanner.next();
			
			//this part will call the system to check credentials
			valid = mainSystemTest.validateCredentials(loginInfo);
			
			if (valid == true)
			{
				System.out.println("\nLogin successful.");
				break;
			}
			System.out.println("\nLogin failed. Type \"cancel\" to cancel login.");
		}
		
		return loginInfo;
	}
	
	
	public void memberMenu() {
		//member menu which allows member to check for discounts, points redeemed and proceed to shopping
		int choice = 0;

		System.out.println("---\tMember Menu\t---");
		
		while (choice==0)
		{
			System.out.println("\n1. Check info and points redeemed\n2. Check for discounts\n3. Proceed to shopping\n");
			System.out.printf(":");
			choice = scanner.nextInt();
			
			//validate Input
			if (choice == 1 || choice == 2 || choice == 3)
			{
				break;
			}
			
			System.out.println("\nInvalid Input!\n");
			choice = 0;
		}
		
		if (choice == 1)
		{
			//when the user wants to check points
			System.out.println("\n- Member Information -");
			int memberId = 001;
			String memberName = "Tester Dummy Name";
			int memberPoints = 0;
			
			System.out.printf("\nMember ID: " + memberId + "\nMember name: " + memberName + "\nMember Points: "
					+ memberPoints);
			
			System.out.println("\nPress any key to continue");
			scanner.next();
		}
	}
	
	public static void clearScreen() {
		//clear command window
	    System.out.print("\033[H\033[2J");  
	    System.out.flush();  
	}  
}
